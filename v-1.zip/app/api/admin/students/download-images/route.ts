import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import JSZip from 'jszip';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const lga = searchParams.get('lga');
    const schoolCode = searchParams.get('schoolCode');
    const registrationType = searchParams.get('registrationType');
    const search = searchParams.get('search');

    console.log('🚀 Starting image download request...');

    // Build filter conditions
    const studentRegWhere: any = {};
    const postRegWhere: any = {};

    if (search) {
      const searchConditions = {
        OR: [
          { firstname: { contains: search, mode: 'insensitive' } },
          { lastname: { contains: search, mode: 'insensitive' } },
          { studentNumber: { contains: search, mode: 'insensitive' } },
        ],
      };
      studentRegWhere.AND = [searchConditions];
      postRegWhere.AND = [searchConditions];
    }

    if (schoolCode) {
      studentRegWhere.school = { schoolCode };
      postRegWhere.school = { schoolCode };
    }

    // Fetch students based on registration type
    let studentRegistrations: any[] = [];
    let postRegistrations: any[] = [];

    if (!registrationType || registrationType === 'all' || registrationType === 'regular' || registrationType === 'late') {
      console.log('📥 Fetching StudentRegistrations...');
      studentRegistrations = await prisma.studentRegistration.findMany({
        where: {
          ...studentRegWhere,
          passport: { not: null },
        },
        select: {
          id: true,
          studentNumber: true,
          firstname: true,
          lastname: true,
          passport: true,
          lateRegistration: true,
        },
      });
      console.log(`   Found ${studentRegistrations.length} with images`);
    }

    if (!registrationType || registrationType === 'all' || registrationType === 'post') {
      console.log('📥 Fetching PostRegistrations...');
      postRegistrations = await prisma.postRegistration.findMany({
        where: {
          ...postRegWhere,
          passport: { not: null },
        },
        select: {
          id: true,
          studentNumber: true,
          firstname: true,
          lastname: true,
          passport: true,
        },
      });
      console.log(`   Found ${postRegistrations.length} with images`);
    }

    // Filter by registration type if needed
    let filteredStudentRegs = studentRegistrations;
    if (registrationType === 'regular') {
      filteredStudentRegs = studentRegistrations.filter(s => !s.lateRegistration);
    } else if (registrationType === 'late') {
      filteredStudentRegs = studentRegistrations.filter(s => s.lateRegistration);
    }

    // Combine all students
    const allStudents = [
      ...filteredStudentRegs.map(s => ({
        studentNumber: s.studentNumber,
        firstname: s.firstname,
        lastname: s.lastname,
        passport: s.passport,
      })),
      ...postRegistrations.map(s => ({
        studentNumber: s.studentNumber,
        firstname: s.firstname,
        lastname: s.lastname,
        passport: s.passport,
      })),
    ];

    console.log(`📊 Total students with images: ${allStudents.length}`);

    if (allStudents.length === 0) {
      return NextResponse.json({ error: 'No students with images found' }, { status: 404 });
    }

    // Create ZIP file
    console.log('📦 Creating ZIP file...');
    const zip = new JSZip();
    let successCount = 0;
    let errorCount = 0;

    for (const student of allStudents) {
      try {
        if (!student.passport) continue;

        let base64Data: string;
        let fileExtension = 'jpg';

        // Extract base64 data from data URL
        if (student.passport.startsWith('data:image/')) {
          const matches = student.passport.match(/^data:image\/([a-zA-Z]+);base64,(.+)$/);
          if (matches && matches.length === 3) {
            fileExtension = matches[1];
            base64Data = matches[2];
          } else {
            const parts = student.passport.split(',');
            if (parts.length === 2) {
              base64Data = parts[1];
            } else {
              console.warn(`⚠️  Invalid format for ${student.studentNumber}`);
              errorCount++;
              continue;
            }
          }
        } else {
          // Assume it's already base64 without prefix
          base64Data = student.passport;
        }

        // Create filename: studentNumber_lastname_firstname.ext
        const sanitizedName = `${student.studentNumber}_${student.lastname}_${student.firstname}`
          .replace(/[^a-zA-Z0-9_-]/g, '_')
          .substring(0, 100);
        
        const filename = `${sanitizedName}.${fileExtension}`;

        // Add to ZIP
        zip.file(filename, base64Data, { base64: true });
        successCount++;

        // Log progress every 1000 images
        if (successCount % 1000 === 0) {
          console.log(`   Progress: ${successCount}/${allStudents.length} images added`);
        }
      } catch (error) {
        console.error(`❌ Error processing ${student.studentNumber}:`, error);
        errorCount++;
      }
    }

    console.log(`✅ Added ${successCount} images to ZIP (${errorCount} errors)`);

    if (successCount === 0) {
      return NextResponse.json({ error: 'Failed to process any images' }, { status: 500 });
    }

    // Generate ZIP blob
    console.log('🗜️  Generating ZIP file...');
    const zipBlob = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });

    console.log(`✅ ZIP generated: ${(zipBlob.length / 1024 / 1024).toFixed(2)} MB`);

    // Send ZIP file
    const timestamp = new Date().toISOString().split('T')[0];
    const filename = `student_images_${timestamp}.zip`;

    return new NextResponse(new Uint8Array(zipBlob), {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': zipBlob.length.toString(),
        'X-Total-Images': successCount.toString(),
        'X-Failed-Images': errorCount.toString(),
      },
    });

  } catch (error) {
    console.error('❌ Download failed:', error);
    return NextResponse.json(
      { error: 'Failed to generate image archive', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
